package ceballos_david_taller1;

import java.util.Random;

import processing.core.PImage;
import processing.core.PVector;

 public class Objeto {
	
	private Main app;
	private int posx;
	private int posy;
	private int boost; 
	private int tipo;
	private int dx;
	private int dy;
	private boolean recogido;
	private PImage gas,meteor;
	

	
	public Objeto(Main app, int tipo) {
		this.app=app;
		this.posx= app.width/2-15;
		this.posy=app.height/2-75;
		this.tipo=tipo;
		
		recogido=false;
		this.dx = (int) app.random(-4,4);
	    this.dy = (int) app.random(-4,4);

		gas= app.loadImage("/src/img/gas.png");
		meteor= app.loadImage("/src/img/ROCA.png");
		
	}
	
	public void pintar() {
		
		if(tipo==1 && recogido==false) {
			app.image(gas,posx,posy);
			boost=1;
			
		} else if(tipo==2 && recogido==false) {
			app.image(meteor,posx,posy);
			boost=-1;
			
		}
		if(dx==0) {
			dx=(int) app.random(-4,4);
		}
		if(dy==0) {
			dy=(int) app.random(-4,4);
		}
			 this.posx += this.dx;
	
	
			 this.posy += this.dy;
		
			 
	 
	}
	
	
	public boolean validar(int x, int y) {
		if(app.dist(posx, posy, x, y) < 50) {
			return true;
		} else {
			return false;
		}
	}
	
	public boolean recogido() {
		
		return recogido;
	}
 
	public int getX() {
		return posx;
	}
	public int getY() {
		return posy;
	}
	
	public int getBoost() {
		return boost;
	}
	
	

}
