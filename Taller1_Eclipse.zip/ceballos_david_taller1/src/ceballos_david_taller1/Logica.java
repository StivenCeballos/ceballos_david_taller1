package ceballos_david_taller1;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Observable;
import java.util.Observer;
import java.util.Random;

import processing.core.PApplet;
import processing.core.PConstants;
import processing.core.PImage;

public class Logica implements Observer{
	
	

	private Jugador jugadores[];
	private Blackhole hole;
	private int time;
	private Main app;
	private PImage fondo,minj1,minj2;
	public  ArrayList<Objeto> objetos= new ArrayList<Objeto>();
	private int contadorMeteoros, contadorGas;
	private Comunicacion ref;
	private boolean j1,j2;
	private int pantallas=1;
	
	
	
	
	
	
	public Logica(Main app) {
		
		this.app=app;
		time=180;
		this.hole= new Blackhole(this.app.width/2-45,this.app.height/2-100,this.app);
		this.jugadores= new Jugador[2];
		this.jugadores[0]= new Jugador(this.app,1,50,175);
		this.jugadores[1]= new Jugador(this.app,2,700,175);
		fondo= app.loadImage("/src/img/fondo.png");
		minj1= app.loadImage("/src/img/nave01.png");
		minj2= app.loadImage("/src/img/nave02.png");
		contadorGas= (int) app.random(1000,1500);
		contadorMeteoros= (int) app.random(500,1000);
		ref = new Comunicacion();
		ref.addObserver(this);
		Thread t = new Thread(ref);
		t.start();
		j1=false;
		j2=false;
		
		
		
		
		
	}
	public void pintar() {
		switch(pantallas) {
		
		case 1:
			app.imageMode(app.CORNER);
			  app.image(fondo,0,0,app.width,app.height);
			  app.image(minj1,620,410,90,90);
			  app.image(minj2,20,415);
			  String timet = "TIME";
			  app.textSize(20);
			  app.textMode(PConstants.CENTER);
			  app.textAlign(PConstants.CENTER);
			  if(this.time<=10) {
				  app.fill(255,0,0);
			  }
			  app.text(timet,app.width/2,440);
			  app.text(this.time,app.width/2,470);
			  app.textSize(70);
			  app.fill(255);
			  app.text(jugadores[0].getVida(), 120, 475);
			  app.text(jugadores[1].getVida(), 750, 475);
			  app.textSize(30);
			
			  if(!j1 && !j2) {
				  app.text("esperando jugadores", 400, 200); 
					try {
						app.text((String)InetAddress.getLocalHost().getHostAddress(),400,300);
					} catch (UnknownHostException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			  }
			  
			  if(j1 && j2 && pantallas==1) {
			  hole.pintar();
			  
			  
				if( app.frameCount %contadorGas==0) {
					   objetos.add(new Objeto(this.app,1));
					   contadorGas= (int) app.random(1000,1500);
					  
				}
				
		    	if(app.frameCount%contadorMeteoros ==0) {
		           objetos.add(new Objeto(this.app,2));
		           contadorMeteoros= (int) app.random(500,1000);
		        
		        
		          
		        	}
		    	
		    	
		    	
		 
		    	for (int i = 0; i < objetos.size(); i++) {
		    		if(objetos.get(i)!= null) {
		    			app.imageMode(app.CENTER);
		    		objetos.get(i).pintar();
		    		}
				}
		    	
		    	for (int i = 0; i < jugadores.length; i++) {
		    		jugadores[i].moverJugador();
		    	}
		    	
		    	for (int i = objetos.size()-1; i >=0 ; i--) {
		    		if(objetos.size()>0) {
		    		if(objetos.get(i).getX()<=0 || objetos.get(i).getX()>=800) {
		    			objetos.remove(i);
		    			break;
		    			
		    		}
		    		if(objetos.get(i).getY()<=0 || objetos.get(i).getY()>=355) {
		    			objetos.remove(i);
		    			break;
		    			
		    		}
		    		for (int j = 0; j < jugadores.length; j++) {

		  			
		        		if(objetos.get(i).validar(jugadores[j].getX(), jugadores[j].getY())) {	
		    
		        				jugadores[j].setVida(jugadores[j].getVida()+objetos.get(i).getBoost());
		        			
		        			objetos.remove(i);
		        			break;
		        			
		        		}
					}
		    		
		    		
		    	}
				
				}
			  if(app.frameCount %60==0) {
				  
				  this.time-=1;
				 
				
			  }
			  app.imageMode(app.CENTER);
			  for (int i = 0; i < jugadores.length; i++) {
					jugadores[i].pintar();
					jugadores[i].moverJugador();
				}
				 
			  }
			  
			  jugadores[0].validarBalas(jugadores[1]);
			  jugadores[1].validarBalas(jugadores[0]);
			  if(jugadores[1].getVida()<=0) {
				  pantallas=2;
			  }
			  if(jugadores[0].getVida()<=0) {
				  pantallas=3;
			  }

			break;
			
		case 2:
			app.imageMode(app.CORNER);
			  app.image(fondo,0,0,app.width,app.height);
			  app.image(minj2,app.width/2-45,200,90,90);
			  app.text("JUGADOR 1 GANA",400, 150);

			break;
		case 3:
			app.imageMode(app.CORNER);
			  app.image(fondo,0,0,app.width,app.height);
			  app.image(minj1,app.width/2-45,200,90,90);
			  app.text("JUGADOR 2 GANA",400, 150);
			break;
		}
	 
	
	}
	@Override
	public void update(Observable arg0, Object arg1) {
	
		final String mensaje= (String) arg1;
		String coo[] =mensaje.split("::");
		for (int i = 0; i < coo.length; i++) {
			coo[i].trim();
		}
		if(j1 && j2 && pantallas==1) {
		if(coo[0].equals("ang1")) {
	
			jugadores[1].setAngle(Integer.parseInt(coo[1].trim()));
			jugadores[1].setVel(Integer.parseInt(coo[2].trim())/30);
		}
		if(coo[0].equals("disp1")) {
//			System.out.println("dispar�");
			jugadores[1].disparar();
		}
		if(coo[0].equals("ang2")) {
			
			jugadores[0].setAngle(Integer.parseInt(coo[1].trim()));
			jugadores[0].setVel(Integer.parseInt(coo[2].trim())/30);
		}
		if(coo[0].equals("disp2")) {
//			System.out.println("dispar�");
			jugadores[0].disparar();
		}
		}
		if(coo[0].equals("con1")) {
			j1=true;
			System.out.println("j1dentro");
			
		}
		
		if(coo[0].equals("con2")) {
			j2=true;
			System.out.println("j2dentro");
		}
	}
	
}
	

	
	
	
		
	
		
		
		
	
	
	
	
	

