package ceballos_david_taller1;

import java.net.InetAddress;
import java.net.UnknownHostException;

import processing.core.PApplet;

public class Main extends PApplet {
	
	private Logica logica;
	
	private PApplet app;

	public static void main(String[] args) {
		PApplet.main("ceballos_david_taller1.Main");

	}
	
	public void settings() {
		size(800,500);
	}
	
	public void setup() {
	
	logica = new Logica(this);
		
	}
	
	public void draw() {
		background(255);
		logica.pintar();
		
	}

}
