package ceballos_david_taller1;

import processing.core.PImage;

public class Blackhole {
	
	private Main app;
	private int posx;
	private int posy;
	private float tam;
	
	private PImage[] holes = new PImage[6];
	

	public Blackhole(int posx, int posy, Main app) {
		
		this.app=app;
		this.posx=posx;
		this.tam=0;
		this.posy=posy;
		for (int i = 0; i < holes.length; i++) {
			this.holes[i]= app.loadImage("/src/img/blackhole"+i+".png");
		}
		
		
	}
	
	public void pintar(){
		
			
				app.image(this.holes[app.frameCount/5 % holes.length],posx-tam/2,posy-tam/2,100+tam,100+tam);
		
			
		
		
	
		if(app.frameCount %3==0 && this.tam<220) {
			  
			  this.tam+=0.05;
			  
		  }
	}
}
