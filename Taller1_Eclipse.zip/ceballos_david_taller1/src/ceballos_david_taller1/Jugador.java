package ceballos_david_taller1;

import java.util.ArrayList;

import processing.core.PApplet;
import processing.core.PImage;
import processing.core.PVector;

public class Jugador {
	
	private Main app;
	private int posx;
	private int posy;
	private int vida;
	private int tipo;
	private int angle;
	private int vel;
	private float angrot=0;
	private PImage img;
	public  ArrayList<Proyectil> proyectiles= new ArrayList<Proyectil>();
	private Jugador jugador;
	
	
	
	
	public Jugador(Main app, int tipo,int posx,int posy){
		
		this.app=app;
		this.tipo=tipo;
		this.posx=posx;
		this.posy=posy;
		this.vida=10;
		this.angle=0;
		this.vel=0;
		img = app.loadImage("/src/img/nave"+tipo+".png");
		
	}
	
	public void pintar() {
	
		
		for (int i = proyectiles.size()-1; i >=0 ; i--) {
    		if(proyectiles.size()>0) {
    		if(proyectiles.get(i).getX()<=0 || proyectiles.get(i).getX()>=800) {
    			proyectiles.remove(i);
    			break;
    			
    		}
    		}
		}
    		
    		for (int i = proyectiles.size()-1; i >=0 ; i--) {
        		if(proyectiles.size()>0) {
        		if(proyectiles.get(i).getY()<=0 || proyectiles.get(i).getY()>=355) {
        			proyectiles.remove(i);
        			break;
        			
        		}
        		}
    		}
    		for (int i = 0; i < proyectiles.size(); i++) {
        		if(proyectiles.get(i)!= null) {
        			app.ellipseMode(app.CENTER);
        		proyectiles.get(i).pintar();
        		}
    		}
    		app.pushMatrix();
    		app.translate(posx,posy);
    		app.rotate(angrot);
    		app.image(img, 0, 0);
    		app.popMatrix();
	}
	
	public void moverJugador() {
		
		if(this.angle!=0 && this.vel!=0) {
		
		PVector mov= PVector.fromAngle(app.radians(-this.angle));
		mov.mult(this.vel);
		angrot = mov.heading()+app.PI/2;
		if( posx+ mov.x>=0 && posx+ mov.x<=800 && posy+ mov.y>=0 && posy+ mov.y<=370) {
			posx += mov.x; 
			posy += mov.y;
		} else if(this.vel==0) {
			mov.mult(this.vel);
			angrot = mov.heading()+app.PI/2;
			if( posx+ mov.x>=0 && posx+ mov.x<=800 && posy+ mov.y>=0 && posy+ mov.y<=370) {
				posx += mov.x; 
				posy += mov.y;
		}
		}
		
		}
	
	}
	
	public int getY() {
		return posy;
	}
	public int getX() {
		return posx;
	}

	public int getVida() {
		return vida;
	}
	
	


	public void setAngle(int angle) {
		this.angle = angle;
	
	}


	public void setVel(int vel) {
		this.vel = vel;
		
	}

	public void setVida(int vida) {
		this.vida = vida;
	}
	
	public void disparar() {
		System.out.println(this.angle);
		 proyectiles.add(new Proyectil(this.app,this.posx,this.posy,this.angle,this.angrot));
	}
	
	public void validarBalas(Jugador jugador) {
		
		this.jugador=jugador;
		for (int i = proyectiles.size()-1; i >=0 ; i--) {
			if (PApplet.dist(proyectiles.get(i).getX(),proyectiles.get(i).getY(), jugador.getX(), jugador.getY()) < 30) {
				jugador.setVida(jugador.getVida()-1);
				proyectiles.remove(i);
			}
		}
		
			
		
		
	}
		
	}



