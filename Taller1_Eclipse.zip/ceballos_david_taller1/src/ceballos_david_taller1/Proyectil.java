package ceballos_david_taller1;

import processing.core.PVector;

public class Proyectil extends Thread {
	
	private Main app;
	private int x;
	private int y;
	private int team;
	private float angle;
	private float rot;
	private boolean exist;
	
	public Proyectil(Main app, int posx, int posy, int angle, float rot) {
		this.app=app;
		this.x=posx;
		this.y=posy;
		this.angle=angle;
		this.rot=rot;
		
	}
	


	public void pintar() {
		
		app.fill(250,250,0);
		app.ellipse(x,y, 10, 10);
		moverProyectil();
		app.fill(255);
		
	}
	
	   public boolean impactar(float otroX, float otroY) {
	        if (this.app.dist(this.x, this.y, otroX, otroY) < 3) {
	            return true;

	        } else {
	            return false;
	        }
	    }
	   
	   
	  public boolean getExist() {
		return exist;
	}

	public int getX() {
		return x;
	}


	public int getY() {
		return y;
	}

	public void moverProyectil() {
		
		PVector mov= PVector.fromAngle(app.radians(-this.angle));
		mov.mult(10);
		rot = mov.heading()+app.PI/2;
		x += mov.x; 
		y += mov.y;
		
	
	}
	  
	  
	
	
	
	

}
