package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;


import java.util.Observable;
import java.util.Observer;

import io.github.controlwear.virtual.joystick.android.JoystickView;

public class Control extends AppCompatActivity implements Observer {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_control);
        final String jugador;
        Button disparo;
        Button con;
        JoystickView joystick;
        String data;
        Bundle extras = getIntent().getExtras();
        data= extras.getString("pass");
        jugador= extras.getString("j");



        disparo = findViewById(R.id.disparo);
        joystick = findViewById(R.id.joystick);
        con=findViewById(R.id.con);
        final Comunicacion ref = new Comunicacion(data);
        Thread t= new Thread(ref);
        t.start();



        disparo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ref.enviar("disp"+jugador+"::");
            }
        });
        con.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ref.enviar("con"+jugador+"::");
            }
        });
        joystick.setOnMoveListener(new JoystickView.OnMoveListener() {
            @Override
            public void onMove(int angle, int strength) {

                ref.enviar("ang"+jugador+"::"+angle+"::"+strength);

            }
        });
    }




    @Override
    public void update(Observable o, Object arg) {

    }
}
