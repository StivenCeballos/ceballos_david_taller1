package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Inicio extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final Button go;
        TextView text;
        Button j1;
        Button j2;
        final TextView ip;
        String pass;
        final String[] j = new String[1];

        go = (Button)findViewById(R.id.go);
        j1 = (Button)findViewById(R.id.j1);
        j2 = (Button)findViewById(R.id.j2);

        text= (TextView)findViewById(R.id.text);
        ip= (TextView)findViewById(R.id.ip);

        j1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                j[0] = "1";
            }
        });

        j2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                j[0] = "2";
            }
        });
        go.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CharSequence valor = ip.getText().toString();
                System.out.println(ip);
                Intent go = new Intent(Inicio.this, Control.class);
                go.putExtra("pass",valor);
                go.putExtra("j",j[0]);
                startActivity(go);
            }
        });
    }
}
